#include <iostream>
#include <string>
#include <map>
using namespace std;

void printInfo(map<string, string> stateDataMap);
bool findCapital(map<string, string> stateDataMap);