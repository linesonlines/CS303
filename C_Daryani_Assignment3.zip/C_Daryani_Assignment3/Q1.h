#include <iostream>
#include <queue>
using namespace std;

void to_rear(queue<int>& old_q);
void printQ(queue<int> q);